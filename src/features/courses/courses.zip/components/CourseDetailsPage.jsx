


export default CourseDetailsPage;